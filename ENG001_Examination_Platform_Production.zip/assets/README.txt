RCJY ENG001 Examination Platform Assets Directory
Static assets, icons, and fonts.
